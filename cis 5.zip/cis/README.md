# CIS430_Final

THE FILES IN THIS PROJECT ARE THE FILES FOR PHONEGAP. INCLUDE ALL PLUGINS HERE.

I WOULD RESYNC THE FILES TO YOUR DESKTOP AND THEN RUN PHONEGAP FROM THE FILES TO TEST ON IPHONE OR ANDROID.

The updated app is using the Framework7 html framework made specifically for iphone and android development.
All the design has been made in two files; the main.html and the schedule.js. Everything else is handled automatically by
the framework. I have been using the documentation on the framework7.io website to build it and using the given variables
from the test.html and the olds.html files.

main.html is split into three seperate files to control the different pages within the app and the views that are displayed.
The class names and the ids are used to capture data and manipulate the dom according to the schedule.js file.

Calendar and Vibration plugins are installed and tested to work on iphone. I have been able to submit a booking


TODO:
<!--Need to add vibration and alerts to the confirmation page. Should be done in the student page within main around line 189-->
<!--Need to add "add to calendar" option to student page after confirmation.-->
<!--        This needs work and needs to include CALENDAR-PHONEGAP-PLUGIN line 441 of Scheduler.js-->
<!--Need to add notification on completion with question to ask if they want to add it to there calendar-->
Need to add the side panel info, links to pages and about.
<!--Need to remove the links from the bottom of the page on the appointment form.-->
Need to adjust the calendar on the appointments page, possibly remove? Also not updating after change of professor.
<!-- Need to fix the icons not appearing when using phonegap, Possible css loss- need to search for more info? -->
Possibly make the main screen more organized.
<!--Possibly create loading screen as the javascript takes a while to load initially.-->
<!-- Need to create logo for phonegap icon -->
<!-- Need to change splash screen on intial load -->
<!-- Need to fix layout issues on the confirmation page. INFO layout is not correct. -->









The MYSQL Database info if needed:
DBServer: dmazzola.com
Username: teamlinq
Password: teamli1785


SimplyBook:
teamlinq
demo
demo123
